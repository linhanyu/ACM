//
// Created by Henry on 16/8/20.
//

#include <cstdio>
#include <iostream>
#define NUM 10


using namespace std;

typedef long long Long;

Long Fib(int n){

    return 0;
}

int main(){
    for (int i = 0; i < NUM; ++i) {
        cout<<Fib(i)<<" "<<endl;
    }
}